<?php


  //stylesheet links
function my_theme_enqueue_styles() {
    $version = wp_get_theme() ->get('version' );
    wp_enqueue_style( 'main-style', get_stylesheet_uri() , array() , $version );
    wp_enqueue_style( 'custom-style', get_template_directory_uri() ."/assets/css/style.css");
    wp_enqueue_style( 'fonts-style', get_template_directory_uri() ."/assets/css/fonts.css" );
    wp_enqueue_style( 'bootstrap-style', get_template_directory_uri() ."/assets/css/bootstrap.css" );
    wp_enqueue_style( 'google-fonts', "//fonts.googleapis.com/css?family=Roboto:100,300,300i,400,500,600,700,900%7CRaleway:500" );
}

add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );


//Javascript links
function my_theme_enqueue_scripts() {
  // Enqueue core.min.js
  wp_enqueue_script(
    'core-main', 
    get_template_directory_uri() . "/assets/js/core.min.js", 
    array(), // dependencies
    null, // version
    true // in footer
  );

  // Enqueue script.js
  wp_enqueue_script(
    'main-script', 
    get_template_directory_uri() . "/assets/js/script.js", 
    array('core-main'), // dependencies
    null, // version
    true // in footer
  );
}

add_action('wp_enqueue_scripts', 'my_theme_enqueue_scripts');


function my_theme_support() {
  // adding dynamic title
  add_theme_support('title-tag');
}

add_action('after_setup_theme', 'my_theme_support');


//register navigation menu
register_nav_menus(
  array( 'primary_menu' => 'header_menu' )

)

?>